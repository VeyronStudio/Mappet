/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.client.model.loading;

import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public interface BakedModelsHooks {
	@Nullable
	Map<class_2960, class_1087> fabric_getExtraModels();

	void fabric_setExtraModels(@Nullable Map<class_2960, class_1087> extraModels);
}
