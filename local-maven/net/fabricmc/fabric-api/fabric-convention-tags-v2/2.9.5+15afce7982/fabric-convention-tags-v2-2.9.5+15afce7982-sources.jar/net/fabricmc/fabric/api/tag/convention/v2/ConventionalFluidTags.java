/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.tag.convention.v2;

import net.fabricmc.fabric.impl.tag.convention.v2.TagRegistration;
import net.minecraft.class_3611;
import net.minecraft.class_6862;

/**
 * See {@link net.minecraft.class_3486} for vanilla tags.
 * Note that addition to some vanilla tags implies having certain functionality.
 * <p></p>
 * Note, fluid tags should not be plural to match the vanilla standard.
 * This is the only tag category exempted from many-different-types plural rule.
 *
 * <p>(See {@link net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants} for the correct droplet rates for containers)
 */
public final class ConventionalFluidTags {
	private ConventionalFluidTags() {
	}

	/**
	 * Holds all fluids related to lava without the behaviors attached to the vanilla lava fluid tag.
	 */
	public static final class_6862<class_3611> LAVA = register("lava");
	/**
	 * Holds all fluids related to water without the behaviors attached to the vanilla water fluid tag.
	 */
	public static final class_6862<class_3611> WATER = register("water");
	/**
	 * Holds all fluids related to milk.
	 */
	public static final class_6862<class_3611> MILK = register("milk");
	/**
	 * Holds all fluids related to honey.
	 */
	public static final class_6862<class_3611> HONEY = register("honey");
	/**
	 * Holds all fluids that are gaseous at room temperature.
	 */
	public static final class_6862<class_3611> GASEOUS = register("gaseous");
	/**
	 * Holds all fluids related to experience.
	 *
	 * <p>(Standard unit for experience is 810 droplet per 1 experience. However, extraction from Bottle o' Enchanting should yield 27000 droplets while smashing yields less)
	 */
	public static final class_6862<class_3611> EXPERIENCE = register("experience");
	/**
	 * Holds all fluids related to potions. The effects of the potion fluid should be read from Data Components.
	 * The effects and color of the potion fluid should be read from {@link net.minecraft.class_9334#field_49651}
	 * component that people should be attaching to the FluidVariant of this fluid.
	 */
	public static final class_6862<class_3611> POTION = register("potion");
	/**
	 * Holds all fluids related to Suspicious Stew.
	 * The effects of the suspicious stew fluid should be read from {@link net.minecraft.class_9334#field_49652}
	 * component that people should be attaching to the FluidVariant of this fluid.
	 */
	public static final class_6862<class_3611> SUSPICIOUS_STEW = register("suspicious_stew");
	/**
	 * Holds all fluids related to Mushroom Stew.
	 */
	public static final class_6862<class_3611> MUSHROOM_STEW = register("mushroom_stew");
	/**
	 * Holds all fluids related to Rabbit Stew.
	 */
	public static final class_6862<class_3611> RABBIT_STEW = register("rabbit_stew");
	/**
	 * Holds all fluids related to Beetroot Soup.
	 */
	public static final class_6862<class_3611> BEETROOT_SOUP = register("beetroot_soup");
	/**
	 * Tag that holds all fluids that recipe viewers should not show to users.
	 */
	public static final class_6862<class_3611> HIDDEN_FROM_RECIPE_VIEWERS = register("hidden_from_recipe_viewers");

	private static class_6862<class_3611> register(String tagId) {
		return TagRegistration.FLUID_TAG.registerC(tagId);
	}
}
