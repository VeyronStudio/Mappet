/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.object.builder.v1.block.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import com.mojang.datafixers.types.Type;

/**
 * Fabric's version of BlockEntityType.Builder with additional convenience methods.
 *
 */
public final class FabricBlockEntityTypeBuilder<T extends class_2586> {
	private final Factory<? extends T> factory;
	private final List<class_2248> blocks;

	private FabricBlockEntityTypeBuilder(Factory<? extends T> factory, List<class_2248> blocks) {
		this.factory = factory;
		this.blocks = blocks;
	}

	public static <T extends class_2586> FabricBlockEntityTypeBuilder<T> create(Factory<? extends T> factory, class_2248... blocks) {
		List<class_2248> blocksList = new ArrayList<>(blocks.length);
		Collections.addAll(blocksList, blocks);

		return new FabricBlockEntityTypeBuilder<>(factory, blocksList);
	}

	/**
	 * Adds a supported block for the block entity type.
	 *
	 * @param block the supported block
	 * @return this builder
	 */
	public FabricBlockEntityTypeBuilder<T> addBlock(class_2248 block) {
		this.blocks.add(block);
		return this;
	}

	/**
	 * Adds supported blocks for the block entity type.
	 *
	 * @param blocks the supported blocks
	 * @return this builder
	 */
	public FabricBlockEntityTypeBuilder<T> addBlocks(class_2248... blocks) {
		Collections.addAll(this.blocks, blocks);
		return this;
	}

	public class_2591<T> build() {
		return build(null);
	}

	public class_2591<T> build(Type<?> type) {
		return new class_2591<T>(factory::create, new HashSet<>(blocks));
	}

	@FunctionalInterface
	public interface Factory<T extends class_2586> {
		T create(class_2338 blockPos, class_2680 blockState);
	}
}
