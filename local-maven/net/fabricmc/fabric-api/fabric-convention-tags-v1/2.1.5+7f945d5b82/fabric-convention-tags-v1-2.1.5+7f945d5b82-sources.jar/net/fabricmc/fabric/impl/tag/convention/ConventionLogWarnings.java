/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.tag.convention;

import java.util.AbstractMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalBiomeTags;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalBlockTags;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalEnchantmentTags;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalItemTags;
import net.fabricmc.fabric.api.tag.convention.v2.TagUtil;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ConventionLogWarnings implements ModInitializer {
	private static final Logger LOGGER = LoggerFactory.getLogger(ConventionLogWarnings.class);

	private static final LogWarningMode LOG_LEGACY_WARNING_MODE = setupLogWarningModeProperty();

	private static LogWarningMode setupLogWarningModeProperty() {
		String property = System.getProperty("fabric-tag-conventions-v1.legacyTagWarning", LogWarningMode.SHORT.name()).toUpperCase(Locale.ROOT);

		try {
			return LogWarningMode.valueOf(property);
		} catch (Exception e) {
			LOGGER.error("Unknown entry `{}` for property `fabric-tag-conventions-v1.legacyTagWarning`.", property);
			return LogWarningMode.SILENCED;
		}
	}

	private enum LogWarningMode {
		SILENCED,
		SHORT,
		VERBOSE,
		FAIL;

		boolean isVerbose() {
			return this == VERBOSE || this == FAIL;
		}
	}

	/**
	 * Old `c` tags that we migrated to a new tag under a new convention.
	 * May also contain commonly used `c` tags that are not following convention.
	 */
	private static final Map<class_6862<?>, class_6862<?>> LEGACY_C_TAGS = Map.<class_6862<?>, class_6862<?>>ofEntries(
			// Old v1 tags that are discouraged
			createMapEntry(ConventionalBlockTags.MOVEMENT_RESTRICTED, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.RELOCATION_NOT_SUPPORTED),
			createMapEntry(ConventionalBlockTags.QUARTZ_ORES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.QUARTZ_ORES),
			createMapEntry(ConventionalBlockTags.WOODEN_BARRELS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.WOODEN_BARRELS),
			createMapEntry(ConventionalBlockTags.SANDSTONE_BLOCKS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.SANDSTONE_BLOCKS),
			createMapEntry(ConventionalBlockTags.SANDSTONE_STAIRS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.SANDSTONE_STAIRS),
			createMapEntry(ConventionalBlockTags.SANDSTONE_SLABS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.SANDSTONE_SLABS),
			createMapEntry(ConventionalBlockTags.RED_SANDSTONE_BLOCKS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.RED_SANDSTONE_BLOCKS),
			createMapEntry(ConventionalBlockTags.RED_SANDSTONE_STAIRS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.RED_SANDSTONE_STAIRS),
			createMapEntry(ConventionalBlockTags.RED_SANDSTONE_SLABS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.RED_SANDSTONE_SLABS),
			createMapEntry(ConventionalBlockTags.UNCOLORED_SANDSTONE_BLOCKS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.UNCOLORED_SANDSTONE_BLOCKS),
			createMapEntry(ConventionalBlockTags.UNCOLORED_SANDSTONE_STAIRS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.UNCOLORED_SANDSTONE_STAIRS),
			createMapEntry(ConventionalBlockTags.UNCOLORED_SANDSTONE_SLABS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.UNCOLORED_SANDSTONE_SLABS),

			createMapEntry(ConventionalItemTags.QUARTZ_ORES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.QUARTZ_ORES),
			createMapEntry(ConventionalItemTags.WOODEN_BARRELS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.WOODEN_BARRELS),
			createMapEntry(ConventionalItemTags.SANDSTONE_BLOCKS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.SANDSTONE_BLOCKS),
			createMapEntry(ConventionalItemTags.SANDSTONE_STAIRS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.SANDSTONE_STAIRS),
			createMapEntry(ConventionalItemTags.SANDSTONE_SLABS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.SANDSTONE_SLABS),
			createMapEntry(ConventionalItemTags.RED_SANDSTONE_BLOCKS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.RED_SANDSTONE_BLOCKS),
			createMapEntry(ConventionalItemTags.RED_SANDSTONE_STAIRS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.RED_SANDSTONE_STAIRS),
			createMapEntry(ConventionalItemTags.RED_SANDSTONE_SLABS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.RED_SANDSTONE_SLABS),
			createMapEntry(ConventionalItemTags.UNCOLORED_SANDSTONE_BLOCKS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.UNCOLORED_SANDSTONE_BLOCKS),
			createMapEntry(ConventionalItemTags.UNCOLORED_SANDSTONE_STAIRS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.UNCOLORED_SANDSTONE_STAIRS),
			createMapEntry(ConventionalItemTags.BLACK_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.BLACK_DYES),
			createMapEntry(ConventionalItemTags.BLUE_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.BLUE_DYES),
			createMapEntry(ConventionalItemTags.BROWN_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.BROWN_DYES),
			createMapEntry(ConventionalItemTags.GREEN_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.GREEN_DYES),
			createMapEntry(ConventionalItemTags.RED_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.RED_DYES),
			createMapEntry(ConventionalItemTags.WHITE_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.WHITE_DYES),
			createMapEntry(ConventionalItemTags.YELLOW_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.YELLOW_DYES),
			createMapEntry(ConventionalItemTags.LIGHT_BLUE_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.LIGHT_BLUE_DYES),
			createMapEntry(ConventionalItemTags.LIGHT_GRAY_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.LIGHT_GRAY_DYES),
			createMapEntry(ConventionalItemTags.LIME_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.LIME_DYES),
			createMapEntry(ConventionalItemTags.MAGENTA_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.MAGENTA_DYES),
			createMapEntry(ConventionalItemTags.ORANGE_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.ORANGE_DYES),
			createMapEntry(ConventionalItemTags.PINK_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.PINK_DYES),
			createMapEntry(ConventionalItemTags.CYAN_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.CYAN_DYES),
			createMapEntry(ConventionalItemTags.GRAY_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.GRAY_DYES),
			createMapEntry(ConventionalItemTags.PURPLE_DYES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.PURPLE_DYES),
			createMapEntry(ConventionalItemTags.RAW_IRON_ORES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.IRON_RAW_MATERIALS),
			createMapEntry(ConventionalItemTags.RAW_GOLD_ORES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.GOLD_RAW_MATERIALS),
			createMapEntry(ConventionalItemTags.DIAMONDS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.DIAMOND_GEMS),
			createMapEntry(ConventionalItemTags.LAPIS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.LAPIS_GEMS),
			createMapEntry(ConventionalItemTags.EMERALDS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.EMERALD_GEMS),
			createMapEntry(ConventionalItemTags.QUARTZ, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.QUARTZ_GEMS),
			createMapEntry(ConventionalItemTags.SHEARS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.SHEAR_TOOLS),
			createMapEntry(ConventionalItemTags.SPEARS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.SPEAR_TOOLS),
			createMapEntry(ConventionalItemTags.BOWS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.BOW_TOOLS),
			createMapEntry(ConventionalItemTags.SHIELDS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.SHIELD_TOOLS),

			createMapEntry(ConventionalEnchantmentTags.INCREASES_BLOCK_DROPS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalEnchantmentTags.INCREASE_BLOCK_DROPS),
			createMapEntry(ConventionalEnchantmentTags.INCREASES_ENTITY_DROPS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalEnchantmentTags.INCREASE_ENTITY_DROPS),
			createMapEntry(ConventionalEnchantmentTags.ENTITY_MOVEMENT_ENHANCEMENT, net.fabricmc.fabric.api.tag.convention.v2.ConventionalEnchantmentTags.ENTITY_SPEED_ENHANCEMENTS),
			createMapEntry(ConventionalEnchantmentTags.ENTITY_DEFENSE_ENHANCEMENT, net.fabricmc.fabric.api.tag.convention.v2.ConventionalEnchantmentTags.ENTITY_DEFENSE_ENHANCEMENTS),

			createMapEntry(ConventionalBiomeTags.IN_NETHER, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_NETHER),
			createMapEntry(ConventionalBiomeTags.IN_THE_END, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_END),
			createMapEntry(ConventionalBiomeTags.IN_OVERWORLD, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_OVERWORLD),
			createMapEntry(ConventionalBiomeTags.CAVES, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_CAVE),
			createMapEntry(ConventionalBiomeTags.CLIMATE_COLD, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_COLD),
			createMapEntry(ConventionalBiomeTags.CLIMATE_TEMPERATE, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_TEMPERATE),
			createMapEntry(ConventionalBiomeTags.CLIMATE_HOT, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_HOT),
			createMapEntry(ConventionalBiomeTags.CLIMATE_WET, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_WET),
			createMapEntry(ConventionalBiomeTags.CLIMATE_DRY, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_DRY),
			createMapEntry(ConventionalBiomeTags.VEGETATION_DENSE, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_VEGETATION_DENSE),
			createMapEntry(ConventionalBiomeTags.VEGETATION_SPARSE, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_VEGETATION_SPARSE),
			createMapEntry(ConventionalBiomeTags.TREE_CONIFEROUS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_CONIFEROUS_TREE),
			createMapEntry(ConventionalBiomeTags.TREE_DECIDUOUS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_DECIDUOUS_TREE),
			createMapEntry(ConventionalBiomeTags.TREE_JUNGLE, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_JUNGLE_TREE),
			createMapEntry(ConventionalBiomeTags.TREE_SAVANNA, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_SAVANNA_TREE),
			createMapEntry(ConventionalBiomeTags.MOUNTAIN_PEAK, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_MOUNTAIN_PEAK),
			createMapEntry(ConventionalBiomeTags.MOUNTAIN_SLOPE, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_MOUNTAIN_SLOPE),
			createMapEntry(ConventionalBiomeTags.END_ISLANDS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_OUTER_END_ISLAND),
			createMapEntry(ConventionalBiomeTags.NETHER_FORESTS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_NETHER_FOREST),
			createMapEntry(ConventionalBiomeTags.FLOWER_FORESTS, net.fabricmc.fabric.api.tag.convention.v2.ConventionalBiomeTags.IS_FLOWER_FOREST),

			// Commonly used `c` tags that are using discouraged conventions. (Not plural or not folder form)
			createMapEntry(class_7924.field_41254, "barrel", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.BARRELS),
			createMapEntry(class_7924.field_41254, "chest", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.CHESTS),
			createMapEntry(class_7924.field_41254, "wooden_chests", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.WOODEN_CHESTS),
			createMapEntry(class_7924.field_41254, "glass", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.GLASS_BLOCKS),
			createMapEntry(class_7924.field_41254, "glass_pane", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.GLASS_PANES),
			createMapEntry(class_7924.field_41254, "immobile", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.RELOCATION_NOT_SUPPORTED),
			createMapEntry(class_7924.field_41254, "stone", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.STONES),
			createMapEntry(class_7924.field_41254, "cobblestone", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.COBBLESTONES),
			createMapEntry(class_7924.field_41254, "workbench", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.VILLAGER_JOB_SITES),
			createMapEntry(class_7924.field_41254, "workbenches", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.VILLAGER_JOB_SITES),
			createMapEntry(class_7924.field_41254, "workstation", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.VILLAGER_JOB_SITES),
			createMapEntry(class_7924.field_41254, "workstations", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.VILLAGER_JOB_SITES),
			createMapEntry(class_7924.field_41254, "crafting_table", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.PLAYER_WORKSTATIONS_CRAFTING_TABLES),
			createMapEntry(class_7924.field_41254, "crafting_tables", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.PLAYER_WORKSTATIONS_CRAFTING_TABLES),
			createMapEntry(class_7924.field_41254, "furnace", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.PLAYER_WORKSTATIONS_FURNACES),
			createMapEntry(class_7924.field_41254, "furnaces", net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags.PLAYER_WORKSTATIONS_FURNACES),

			createMapEntry(class_7924.field_41197, "axes", class_3489.field_42612),
			createMapEntry(class_7924.field_41197, "pickaxes", class_3489.field_42614),
			createMapEntry(class_7924.field_41197, "hoes", class_3489.field_42613),
			createMapEntry(class_7924.field_41197, "shovels", class_3489.field_42615),
			createMapEntry(class_7924.field_41197, "swords", class_3489.field_42611),
			createMapEntry(class_7924.field_41197, "wrenches", "tools/wrenches"),
			createMapEntry(createTagKeyUnderFabric(class_7924.field_41197, "axes"), class_3489.field_42612),
			createMapEntry(createTagKeyUnderFabric(class_7924.field_41197, "pickaxes"), class_3489.field_42614),
			createMapEntry(createTagKeyUnderFabric(class_7924.field_41197, "hoes"), class_3489.field_42613),
			createMapEntry(createTagKeyUnderFabric(class_7924.field_41197, "shovels"), class_3489.field_42615),
			createMapEntry(createTagKeyUnderFabric(class_7924.field_41197, "swords"), class_3489.field_42611),
			createMapEntry(class_7924.field_41197, "barrel", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.BARRELS),
			createMapEntry(class_7924.field_41197, "chest", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.CHESTS),
			createMapEntry(class_7924.field_41197, "glass", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.GLASS_BLOCKS),
			createMapEntry(class_7924.field_41197, "glass_pane", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.GLASS_PANES),
			createMapEntry(class_7924.field_41197, "glowstone_dusts", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.GLOWSTONE_DUSTS),
			createMapEntry(class_7924.field_41197, "redstone_dusts", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.REDSTONE_DUSTS),
			createMapEntry(class_7924.field_41197, "stone", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.STONES),
			createMapEntry(class_7924.field_41197, "string", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.STRINGS),
			createMapEntry(class_7924.field_41197, "sticks", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.WOODEN_RODS),
			createMapEntry(class_7924.field_41197, "wooden_rods", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.WOODEN_RODS),
			createMapEntry(class_7924.field_41197, "food", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.FOODS),
			createMapEntry(class_7924.field_41197, "fruit", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.FRUIT_FOODS),
			createMapEntry(class_7924.field_41197, "fruits", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.FRUIT_FOODS),
			createMapEntry(class_7924.field_41197, "vegetable", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.VEGETABLE_FOODS),
			createMapEntry(class_7924.field_41197, "vegetables", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.VEGETABLE_FOODS),
			createMapEntry(class_7924.field_41197, "berry", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.BERRY_FOODS),
			createMapEntry(class_7924.field_41197, "berries", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.BERRY_FOODS),
			createMapEntry(class_7924.field_41197, "bread", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.BREAD_FOODS),
			createMapEntry(class_7924.field_41197, "breads", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.BREAD_FOODS),
			createMapEntry(class_7924.field_41197, "cookie", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.COOKIE_FOODS),
			createMapEntry(class_7924.field_41197, "cookies", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.COOKIE_FOODS),
			createMapEntry(class_7924.field_41197, "raw_meat", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.RAW_MEAT_FOODS),
			createMapEntry(class_7924.field_41197, "raw_meats", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.RAW_MEAT_FOODS),
			createMapEntry(class_7924.field_41197, "raw_fish", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.RAW_FISH_FOODS),
			createMapEntry(class_7924.field_41197, "raw_fishes", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.RAW_FISH_FOODS),
			createMapEntry(class_7924.field_41197, "cooked_meat", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.COOKED_MEAT_FOODS),
			createMapEntry(class_7924.field_41197, "cooked_meats", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.COOKED_MEAT_FOODS),
			createMapEntry(class_7924.field_41197, "cooked_fish", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.COOKED_FISH_FOODS),
			createMapEntry(class_7924.field_41197, "cooked_fishes", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.COOKED_FISH_FOODS),
			createMapEntry(class_7924.field_41197, "soup", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.SOUP_FOODS),
			createMapEntry(class_7924.field_41197, "soups", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.SOUP_FOODS),
			createMapEntry(class_7924.field_41197, "stew", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.SOUP_FOODS),
			createMapEntry(class_7924.field_41197, "stews", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.SOUP_FOODS),
			createMapEntry(class_7924.field_41197, "candy", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.CANDY_FOODS),
			createMapEntry(class_7924.field_41197, "candies", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.CANDY_FOODS),
			createMapEntry(class_7924.field_41197, "pie", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.PIE_FOODS),
			createMapEntry(class_7924.field_41197, "pies", net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.PIE_FOODS),
			createMapEntry(class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("minecraft", "music_discs")), net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags.MUSIC_DISCS)
	);

	@Override
	public void onInitialize() {
		if (FabricLoader.getInstance().isDevelopmentEnvironment() && LOG_LEGACY_WARNING_MODE != LogWarningMode.SILENCED) {
			setupLegacyTagWarning();
		}
	}

	private static void setupLegacyTagWarning() {
		// Log tags that are still using legacy conventions under 'c' namespace
		ServerLifecycleEvents.SERVER_STARTED.register(server -> {
			List<class_6862<?>> legacyTags = new ObjectArrayList<>();
			class_5455.class_6890 dynamicRegistries = server.method_30611();

			// We only care about vanilla registries
			dynamicRegistries.method_40311().forEach(registryEntry -> {
				if (registryEntry.comp_350().method_29177().method_12836().equals(class_2960.field_33381)) {
					registryEntry.comp_351().method_40272().forEach(listEntry -> {
						class_6862<?> tagKey = class_6862.method_40092(registryEntry.comp_350(), listEntry.method_40251().comp_327());

						// Grab legacy tags we migrated or discourage
						if (LEGACY_C_TAGS.containsKey(tagKey)) {
							legacyTags.add(tagKey);
						}
					});
				}
			});

			if (legacyTags.isEmpty()) {
				return;
			}

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("""
					\n	Dev warning - Legacy Tags detected. Please migrate your old tags to our new format that follows better conventions!
						See classes under net.fabricmc.fabric.api.tag.convention.v2 package for all tags.

						NOTE: Many tags have been moved around or renamed. Some new ones were added so please review the new tags.
						And make sure you follow tag conventions for new tags! The convention is `c` with nouns generally being plural and adjectives being singular.
						You can disable this message by this system property to your runs: `-Dfabric-tag-conventions-v1.legacyTagWarning=SILENCED`.
						To see individual legacy tags found, set the system property to `-Dfabric-tag-conventions-v1.legacyTagWarning=VERBOSE` instead. Default is `SHORT`.
					""");

			// Print out all legacy tags when desired.
			if (LOG_LEGACY_WARNING_MODE.isVerbose()) {
				stringBuilder.append("\nLegacy tags and their replacement:");

				for (class_6862<?> tagKey : legacyTags) {
					stringBuilder.append("\n     ").append(tagKey).append("  ->  ").append(LEGACY_C_TAGS.get(tagKey));
				}
			}

			LOGGER.warn(stringBuilder.toString());

			if (LOG_LEGACY_WARNING_MODE == LogWarningMode.FAIL) {
				throw new RuntimeException("Legacy Tag validation failed");
			}
		});
	}

	private static <T> AbstractMap.SimpleEntry<class_6862<T>, class_6862<T>> createMapEntry(class_6862<T> tag1, class_6862<T> tag2) {
		return new AbstractMap.SimpleEntry<>(tag1, tag2);
	}

	private static <T> AbstractMap.SimpleEntry<class_6862<T>, class_6862<T>> createMapEntry(class_5321<class_2378<T>> registryKey, String tagId1, class_6862<T> tag2) {
		return new AbstractMap.SimpleEntry<>(createTagKeyUnderC(registryKey, tagId1), tag2);
	}

	private static <T> AbstractMap.SimpleEntry<class_6862<T>, class_6862<T>> createMapEntry(class_5321<class_2378<T>> registryKey, String tagId1, String tagId2) {
		return new AbstractMap.SimpleEntry<>(createTagKeyUnderC(registryKey, tagId1), createTagKeyUnderC(registryKey, tagId2));
	}

	private static <T> class_6862<T> createTagKeyUnderC(class_5321<class_2378<T>> registryKey, String tagId) {
		return class_6862.method_40092(registryKey, class_2960.method_60655(TagUtil.C_TAG_NAMESPACE, tagId));
	}

	private static <T> class_6862<T> createTagKeyUnderFabric(class_5321<class_2378<T>> registryKey, String tagId) {
		return class_6862.method_40092(registryKey, class_2960.method_60655(TagUtil.FABRIC_TAG_NAMESPACE, tagId));
	}
}
