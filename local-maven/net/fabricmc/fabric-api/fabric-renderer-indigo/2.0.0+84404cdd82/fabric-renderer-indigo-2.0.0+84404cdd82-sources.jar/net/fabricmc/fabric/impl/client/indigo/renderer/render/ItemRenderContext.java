/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.client.indigo.renderer.render;

import java.util.Arrays;
import java.util.function.Supplier;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.GlintMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.impl.client.indigo.renderer.helper.ColorHelper;
import net.fabricmc.fabric.impl.client.indigo.renderer.mesh.MutableQuadViewImpl;
import net.fabricmc.fabric.mixin.client.indigo.renderer.ItemRendererAccessor;
import net.minecraft.class_10444;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4722;
import net.minecraft.class_5819;
import net.minecraft.class_765;
import net.minecraft.class_7837;
import net.minecraft.class_811;
import net.minecraft.class_918;

/**
 * Used during item buffering to invoke {@link class_1087#emitItemQuads}.
 */
public class ItemRenderContext extends AbstractRenderContext {
	/** Value vanilla uses for item rendering. The only sensible choice, of course.  */
	private static final long ITEM_RANDOM_SEED = 42L;
	private static final int GLINT_COUNT = class_10444.class_10445.values().length;

	private final class_5819 random = class_5819.method_43047();
	private final Supplier<class_5819> randomSupplier = () -> {
		random.method_43052(ITEM_RANDOM_SEED);
		return random;
	};

	private class_811 transformMode;
	private class_4587 matrixStack;
	private class_4597 vertexConsumerProvider;
	private int lightmap;
	private int[] tints;

	private class_1921 defaultLayer;
	private class_10444.class_10445 defaultGlint;

	private class_4587.class_4665 specialGlintEntry;
	private final class_4588[] vertexConsumerCache = new class_4588[3 * GLINT_COUNT];

	public void render(class_811 transformationMode, class_4587 matrixStack, class_4597 vertexConsumerProvider, int lightmap, int overlay, int[] tints, class_1087 model, class_1921 layer, class_10444.class_10445 glint) {
		this.transformMode = transformationMode;
		this.matrixStack = matrixStack;
		this.vertexConsumerProvider = vertexConsumerProvider;
		this.lightmap = lightmap;
		this.overlay = overlay;
		this.tints = tints;

		defaultLayer = layer;
		defaultGlint = glint;

		matrix = matrixStack.method_23760().method_23761();
		normalMatrix = matrixStack.method_23760().method_23762();

		model.emitItemQuads(getEmitter(), randomSupplier);

		this.matrixStack = null;
		this.vertexConsumerProvider = null;
		this.tints = null;

		specialGlintEntry = null;
		Arrays.fill(vertexConsumerCache, null);
	}

	@Override
	protected void bufferQuad(MutableQuadViewImpl quad) {
		final RenderMaterial mat = quad.material();
		final boolean emissive = mat.emissive();
		final class_4588 vertexConsumer = getVertexConsumer(mat.blendMode(), mat.glintMode());

		tintQuad(quad);
		shadeQuad(quad, emissive);
		bufferQuad(quad, vertexConsumer);
	}

	private void tintQuad(MutableQuadViewImpl quad) {
		int tintIndex = quad.tintIndex();

		if (tintIndex != -1 && tintIndex < tints.length) {
			final int tint = tints[tintIndex];

			for (int i = 0; i < 4; i++) {
				quad.color(i, ColorHelper.multiplyColor(tint, quad.color(i)));
			}
		}
	}

	private void shadeQuad(MutableQuadViewImpl quad, boolean emissive) {
		if (emissive) {
			for (int i = 0; i < 4; i++) {
				quad.lightmap(i, class_765.field_32767);
			}
		} else {
			final int lightmap = this.lightmap;

			for (int i = 0; i < 4; i++) {
				quad.lightmap(i, ColorHelper.maxBrightness(quad.lightmap(i), lightmap));
			}
		}
	}

	private class_4588 getVertexConsumer(BlendMode blendMode, GlintMode glintMode) {
		class_1921 layer;
		class_10444.class_10445 glint;

		if (blendMode == BlendMode.DEFAULT) {
			layer = defaultLayer;
		} else {
			layer = blendMode == BlendMode.TRANSLUCENT ? class_4722.method_29382() : class_4722.method_24074();
		}

		if (glintMode == GlintMode.DEFAULT) {
			glint = defaultGlint;
		} else {
			glint = glintMode.glint;
		}

		int cacheIndex;

		if (layer == class_4722.method_29382()) {
			cacheIndex = 0;
		} else if (layer == class_4722.method_24074()) {
			cacheIndex = GLINT_COUNT;
		} else {
			cacheIndex = 2 * GLINT_COUNT;
		}

		cacheIndex += glint.ordinal();
		class_4588 vertexConsumer = vertexConsumerCache[cacheIndex];

		if (vertexConsumer == null) {
			vertexConsumer = createVertexConsumer(layer, glint);
			vertexConsumerCache[cacheIndex] = vertexConsumer;
		}

		return vertexConsumer;
	}

	private class_4588 createVertexConsumer(class_1921 layer, class_10444.class_10445 glint) {
		if (glint == class_10444.class_10445.field_55343) {
			if (specialGlintEntry == null) {
				specialGlintEntry = matrixStack.method_23760().method_56822();

				if (transformMode == class_811.field_4317) {
					class_7837.method_46414(specialGlintEntry.method_23761(), 0.5F);
				} else if (transformMode.method_29998()) {
					class_7837.method_46414(specialGlintEntry.method_23761(), 0.75F);
				}
			}

			return ItemRendererAccessor.fabric_getDynamicDisplayGlintConsumer(vertexConsumerProvider, layer, specialGlintEntry);
		}

		return class_918.method_23181(vertexConsumerProvider, layer, true, glint != class_10444.class_10445.field_55341);
	}
}
