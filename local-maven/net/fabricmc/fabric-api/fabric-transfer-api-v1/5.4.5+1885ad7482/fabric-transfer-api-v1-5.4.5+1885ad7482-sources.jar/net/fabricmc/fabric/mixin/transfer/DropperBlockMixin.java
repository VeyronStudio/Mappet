/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.transfer;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageUtil;
import net.fabricmc.fabric.impl.transfer.TransferApiImpl;
import net.minecraft.class_2315;
import net.minecraft.class_2325;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2601;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/**
 * Allows droppers to insert into ItemVariant storages.
 */
@Mixin(class_2325.class)
public class DropperBlockMixin {
	@Inject(
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/block/dispenser/DispenserBehavior;dispense(Lnet/minecraft/util/math/BlockPointer;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack;"
			),
			method = "dispense",
			cancellable = true,
			allow = 1
	)
	public void hookDispense(class_3218 world, class_2680 blockState, class_2338 pos, CallbackInfo ci) {
		class_2601 dispenser = (class_2601) world.method_8321(pos);
		class_2350 direction = dispenser.method_11010().method_11654(class_2315.field_10918);

		Storage<ItemVariant> target = ItemStorage.SIDED.find(world, pos.method_10093(direction), direction.method_10153());

		if (target != null) {
			// Always cancel if a storage is available.
			ci.cancel();

			// We pick a non empty slot. It's not necessarily the same as the one vanilla picked, but that doesn't matter.
			int slot = dispenser.method_11076(world.field_9229);

			if (slot == -1) {
				TransferApiImpl.LOGGER.warn("Skipping dropper transfer because the empty slot is unexpectedly -1.");
				return;
			}

			StorageUtil.move(
					InventoryStorage.of(dispenser, null).getSlot(slot),
					target,
					k -> true,
					1,
					null
			);
		}
	}
}
