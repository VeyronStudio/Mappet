/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.transfer.v1.item;

import java.util.List;

import org.jetbrains.annotations.Nullable;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiLookup;
import net.fabricmc.fabric.api.lookup.v1.item.ItemApiLookup;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.base.SingleStackStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.CombinedSlottedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.CombinedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SidedStorageBlockEntity;
import net.fabricmc.fabric.impl.transfer.item.BundleContentsStorage;
import net.fabricmc.fabric.impl.transfer.item.ComposterWrapper;
import net.fabricmc.fabric.impl.transfer.item.ContainerComponentStorage;
import net.fabricmc.fabric.mixin.transfer.DoubleInventoryAccessor;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1278;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2281;
import net.minecraft.class_2350;
import net.minecraft.class_2595;
import net.minecraft.class_2960;
import net.minecraft.class_3954;

/**
 * Access to {@link Storage Storage&lt;ItemVariant&gt;} instances.
 */
public final class ItemStorage {
	/**
	 * Sided block access to item variant storages.
	 * The {@code Direction} parameter may be null, meaning that the full inventory (ignoring side restrictions) should be queried.
	 * Refer to {@link BlockApiLookup} for documentation on how to use this field.
	 *
	 * <p>When the operations supported by a storage change,
	 * that is if the return value of {@link Storage#supportsInsertion} or {@link Storage#supportsExtraction} changes,
	 * the storage should notify its neighbors with a block update so that they can refresh their connections if necessary.
	 *
	 * <p>Block entities directly implementing {@link class_1263} or {@link class_1278} are automatically handled by a fallback provider,
	 * and don't need to do anything.
	 * Blocks that implement {@link class_3954} and whose returned inventory is constant (it's the same for two subsequent calls)
	 * are also handled automatically and don't need to do anything.
	 * The fallback provider assumes that the {@link class_1263} "owns" its contents. If that's not the case,
	 * for example because it redirects all function calls to another inventory, then implementing {@link class_1263} should be avoided.
	 *
	 * <p>Hoppers and droppers will interact with storages exposed through this lookup, thus implementing one of the vanilla APIs is not necessary.
	 *
	 * <p>Depending on the use case, the following strategies can be used to offer a {@code Storage<ItemVariant>} implementation:
	 * <ul>
	 *     <li>Directly implementing {@code Inventory} or {@code SidedInventory} on a block entity - it will be wrapped automatically.</li>
	 *     <li>Storing an inventory inside a block entity field, and converting it manually with {@link InventoryStorage#of}.
	 *     {@link class_1277} can be used for easy implementation.</li>
	 *     <li>{@link SingleStackStorage} can also be used for more flexibility. Multiple of them can be combined with {@link CombinedStorage}.</li>
	 *     <li>Directly providing a custom implementation of {@code Storage<ItemVariant>} is also possible.</li>
	 * </ul>
	 *
	 * <p>A simple way to expose item variant storages for a block entity hierarchy is to extend {@link SidedStorageBlockEntity}.
	 *
	 * <p>This may be queried safely both on the logical server and on the logical client threads.
	 * On the server thread (i.e. with a server world), all transfer functionality is always supported.
	 * On the client thread (i.e. with a client world), contents of queried Storages are unreliable and should not be modified.
	 */
	public static final BlockApiLookup<Storage<ItemVariant>, @Nullable class_2350> SIDED =
			BlockApiLookup.get(class_2960.method_60655("fabric", "sided_item_storage"), Storage.asClass(), class_2350.class);

	/**
	 * Item access to item variant storages.
	 * Querying should happen through {@link ContainerItemContext#find}.
	 *
	 * <p>This may be queried both client-side and server-side.
	 * Returned APIs should behave the same regardless of the logical side.
	 */
	public static final ItemApiLookup<Storage<ItemVariant>, ContainerItemContext> ITEM =
			ItemApiLookup.get(class_2960.method_60655("fabric", "item_storage"), Storage.asClass(), ContainerItemContext.class);

	private ItemStorage() {
	}

	static {
		// Composter support.
		ItemStorage.SIDED.registerForBlocks((world, pos, state, blockEntity, direction) -> ComposterWrapper.get(world, pos, direction), class_2246.field_17563);

		// Support for SidedStorageBlockEntity.
		ItemStorage.SIDED.registerFallback((world, pos, state, blockEntity, direction) -> {
			if (blockEntity instanceof SidedStorageBlockEntity sidedStorageBlockEntity) {
				return sidedStorageBlockEntity.getItemStorage(direction);
			}

			return null;
		});

		// Register Inventory fallback.
		ItemStorage.SIDED.registerFallback((world, pos, state, blockEntity, direction) -> {
			class_1263 inventoryToWrap = null;

			if (state.method_26204() instanceof class_3954 provider) {
				class_1278 first = provider.method_17680(state, world, pos);
				class_1278 second = provider.method_17680(state, world, pos);

				// Hopefully we can trust the sided inventory not to change.
				if (first == second && first != null) {
					return InventoryStorage.of(first, direction);
				}
			}

			if (blockEntity instanceof class_1263 inventory) {
				if (blockEntity instanceof class_2595 && state.method_26204() instanceof class_2281 chestBlock) {
					inventoryToWrap = class_2281.method_17458(chestBlock, state, world, pos, true);

					// For double chests, we need to retrieve a wrapper for each part separately.
					if (inventoryToWrap instanceof DoubleInventoryAccessor accessor) {
						SlottedStorage<ItemVariant> first = InventoryStorage.of(accessor.fabric_getFirst(), direction);
						SlottedStorage<ItemVariant> second = InventoryStorage.of(accessor.fabric_getSecond(), direction);

						return new CombinedSlottedStorage<>(List.of(first, second));
					}
				} else {
					inventoryToWrap = inventory;
				}
			}

			return inventoryToWrap != null ? InventoryStorage.of(inventoryToWrap, direction) : null;
		});

		ItemStorage.ITEM.registerForItems(
				(itemStack, context) -> new ContainerComponentStorage(context, 27),
				class_1802.field_8545,
				class_1802.field_8722,
				class_1802.field_8380,
				class_1802.field_8050,
				class_1802.field_8829,
				class_1802.field_8271,
				class_1802.field_8548,
				class_1802.field_8520,
				class_1802.field_8627,
				class_1802.field_8451,
				class_1802.field_8213,
				class_1802.field_8816,
				class_1802.field_8350,
				class_1802.field_8584,
				class_1802.field_8461,
				class_1802.field_8676,
				class_1802.field_8268
		);

		ItemStorage.ITEM.registerForItems(
				(itemStack, context) -> new BundleContentsStorage(context),
				class_1802.field_27023,
				class_1802.field_54302,
				class_1802.field_54303,
				class_1802.field_54304,
				class_1802.field_54305,
				class_1802.field_54306,
				class_1802.field_54307,
				class_1802.field_54308,
				class_1802.field_54309,
				class_1802.field_54310,
				class_1802.field_54311,
				class_1802.field_54312,
				class_1802.field_54313,
				class_1802.field_54314,
				class_1802.field_54315,
				class_1802.field_54316,
				class_1802.field_54317
		);
	}
}
